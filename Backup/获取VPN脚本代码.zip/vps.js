const crypto = require('crypto');
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');

const AES_KEY = '999f75dcb1b89a6c528dfn33df4f70d1';
const AES_IV = '5k2f5cjt9a4c1c99';
const OSS_CONFIG_URL = 'https://qiyuqiyu.oss-ap-northeast-1.aliyuncs.com/200255.log';
const API_BASE_FALLBACK = 'http://8.210.52.158/apiV2';
let API_BASE = API_BASE_FALLBACK;

function fetchApiBase() {
    return new Promise((resolve) => {
        https.get(OSS_CONFIG_URL, res => {
            let data = '';
            res.on('data', c => data += c);
            res.on('end', () => {
                try {
                    resolve(JSON.parse(data).log || API_BASE_FALLBACK);
                } catch {
                    resolve(API_BASE_FALLBACK);
                }
            });
        }).on('error', () => resolve(API_BASE_FALLBACK));
    });
}

function decryptResponse(b64) {
    const d = crypto.createDecipheriv('aes-256-cbc', Buffer.from(AES_KEY), Buffer.from(AES_IV));
    return Buffer.concat([d.update(Buffer.from(b64, 'base64')), d.final()]).toString('utf8');
}

function encryptRequest(json) {
    const c = crypto.createCipheriv('aes-256-cbc', Buffer.from(AES_KEY), Buffer.from(AES_IV));
    return Buffer.concat([c.update(Buffer.from(json, 'utf8')), c.final()]).toString('base64');
}

function post(apiPath, headers = {}) {
    return new Promise((resolve, reject) => {
        const url = API_BASE + apiPath;
        const proto = url.startsWith('https') ? https : http;
        const req = proto.request(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json; charset=utf-8',
                'Content-Length': '0',
                ...headers
            }
        }, res => {
            let data = '';
            res.on('data', c => data += c);
            res.on('end', () => resolve(data));
        });
        req.on('error', reject);
        req.end();
    });
}

function parseResponse(raw) {
    try {
        return JSON.parse(decryptResponse(raw));
    } catch (e) {
        try {
            return JSON.parse(raw);
        } catch {
            return {
                raw,
                error: e.message
            };
        }
    }
}

async function travelerLogin(deviceId, token = '') {
    const raw = await post('/traveler_login', {
        deviceId,
        devicetype: '2',
        devicename: 'iPhone',
        language: '1',
        authtoken: token,
        token,
    });
    return parseResponse(raw);
}

async function info(authtoken, jwt, deviceId) {
    const raw = await post('/info', {
        deviceId,
        devicetype: '2',
        devicename: 'iPhone',
        language: '1',
        authtoken,
        token: jwt,
    });
    return parseResponse(raw);
}

async function nodeList(authtoken, jwt, deviceId) {
    const raw = await post('/node_list', {
        deviceId,
        devicetype: '2',
        devicename: 'iPhone',
        language: '1',
        authtoken,
        token: jwt,
    });
    return parseResponse(raw);
}

/**
 * 将文件内容进行 Base64 编码并保存为新文件
 * @param {string} inputFile - 输入文件路径
 * @param {string} outputFile - 输出文件路径（可选，默认在输入文件同目录生成 _base64 后缀文件）
 * @returns {Promise<string>} - 返回 Base64 编码后的内容
 */
function encodeFileToBase64(inputFile, outputFile = null) {
    return new Promise((resolve, reject) => {
        // 如果未指定输出文件，自动生成：原文件名_base64.txt
        if (!outputFile) {
            const parsed = path.parse(inputFile);
            outputFile = path.join(parsed.dir, `${parsed.name}_base64${parsed.ext}`);
        }

        fs.readFile(inputFile, (err, data) => {
            if (err) {
                reject(err);
                return;
            }

            const base64Content = data.toString('base64');
            
            // 写入 Base64 编码后的文件
            fs.writeFile(outputFile, base64Content, (writeErr) => {
                if (writeErr) {
                    reject(writeErr);
                    return;
                }
                resolve(base64Content);
            });
        });
    });
}

/**
 * 为 nodes.txt 生成 Base64 编码版本（同步版本，便于在 main 中直接使用）
 * @param {string} nodesFilePath - nodes.txt 文件路径
 * @returns {string|null} - 返回 Base64 内容或 null（失败时）
 */
function encodeNodeFile(nodesFilePath) {
    try {
        if (!fs.existsSync(nodesFilePath)) {
            console.log(`[!] 文件不存在: ${nodesFilePath}`);
            return null;
        }
        
        const fileContent = fs.readFileSync(nodesFilePath);
        const base64Content = fileContent.toString('base64');
        const base64FilePath = nodesFilePath.replace(/\.txt$/, '_base64.txt');
        
        fs.writeFileSync(base64FilePath, base64Content);
        console.log(`[*] Base64 编码完成: ${base64FilePath}`);
        console.log(`[*] Base64 内容预览 (前100字符): ${base64Content.substring(0, 100)}...`);
        
        return base64Content;
    } catch (err) {
        console.error(`[!] Base64 编码失败: ${err.message}`);
        return null;
    }
}

async function main() {
    API_BASE = await fetchApiBase();
    console.log(`[*] API: ${API_BASE}`);

    const deviceId = crypto.randomUUID();
    const loginRes = await travelerLogin(deviceId);
    if (!loginRes.data?.token) {
        console.log('[!] login failed');
        return;
    }

    const {
        token: authtoken,
        auth_data: jwt
    } = loginRes.data;
    console.log(`[*] authtoken: ${authtoken}`);

    const infoRes = await info(authtoken, jwt, deviceId);
    console.log('[*] info:', JSON.stringify(infoRes));

    const nodeRes = await nodeList(authtoken, jwt, deviceId);
    if (nodeRes.data && Array.isArray(nodeRes.data)) {
        const allNodes = nodeRes.data.flatMap(g => g.node || []);
        const outFile = path.join(path.dirname(process.argv[1]), 'nodes.txt');
        fs.writeFileSync(outFile, allNodes.join('\n'), 'utf8');
        console.log(`[*] ${allNodes.length} nodes -> ${outFile}`);
        
        // 新增：自动生成 nodes.txt 的 Base64 编码版本
        console.log('[*] 正在生成 Base64 编码文件...');
        encodeNodeFile(outFile);
    }
}

// 如果直接运行此脚本，执行 main 函数
if (require.main === module) {
    main().catch(e => console.error('FATAL:', e));
}

module.exports = {
    decryptResponse,
    encryptRequest,
    travelerLogin,
    info,
    nodeList,
    encodeFileToBase64,
    encodeNodeFile
};
