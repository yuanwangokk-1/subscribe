const crypto = require('crypto');
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');

const AES_KEY = '999f75dcb1b89a6c528dfn33df4f70d1';
const AES_IV = '5k2f5cjt9a4c1c99';
const OSS_CONFIG_URL = 'https://qiyuqiyu.oss-ap-northeast-1.aliyuncs.com/200255.log';
const API_BASE_FALLBACK = 'http://8.210.52.158/apiV2';
let API_BASE = API_BASE_FALLBACK;

function fetchApiBase() {
    return new Promise((resolve) => {
        https.get(OSS_CONFIG_URL, res => {
            let data = '';
            res.on('data', c => data += c);
            res.on('end', () => {
                try {
                    resolve(JSON.parse(data).log || API_BASE_FALLBACK);
                } catch {
                    resolve(API_BASE_FALLBACK);
                }
            });
        }).on('error', () => resolve(API_BASE_FALLBACK));
    });
}

// function decryptResponse(buffer) {
// const d = crypto.createDecipheriv('aes-256-cbc', Buffer.from(AES_KEY), Buffer.from(AES_IV));
// return Buffer.concat([d.update(buffer), d.final()]).toString('utf8');
// }

// function encryptRequest(json) {
// const c = crypto.createCipheriv('aes-256-cbc', Buffer.from(AES_KEY), Buffer.from(AES_IV));
// return Buffer.concat([c.update(Buffer.from(json, 'utf8')), c.final()]).toString('base64');
// }

function decryptResponse(b64) {
    const d = crypto.createDecipheriv('aes-256-cbc', Buffer.from(AES_KEY), Buffer.from(AES_IV));
    return Buffer.concat([d.update(Buffer.from(b64, 'base64')), d.final()]).toString('utf8');
}

function encryptRequest(json) {
    const c = crypto.createCipheriv('aes-256-cbc', Buffer.from(AES_KEY), Buffer.from(AES_IV));
    return Buffer.concat([c.update(Buffer.from(json, 'utf8')), c.final()]).toString('base64');
}

function post(apiPath, headers = {}) {
    return new Promise((resolve, reject) => {
        const url = API_BASE + apiPath;
        const proto = url.startsWith('https') ? https : http;
        const req = proto.request(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json; charset=utf-8',
                'Content-Length': '0',
                ...headers
            }
        }, res => {
            let data = '';
            res.on('data', c => data += c);
            res.on('end', () => resolve(data));
        });
        req.on('error', reject);
        req.end();
    });
}

function parseResponse(raw) {
    try {
        return JSON.parse(decryptResponse(raw));
    } catch (e) {
        try {
            return JSON.parse(raw);
        } catch {
            return {
                raw,
                error: e.message
            };
        }
    }
}

async function travelerLogin(deviceId, token = '') {
    const raw = await post('/traveler_login', {
        deviceId,
        devicetype: '2',
        devicename: 'iPhone',
        language: '1',
        authtoken: token,
        token,
    });
    return parseResponse(raw);
}

async function info(authtoken, jwt, deviceId) {
    const raw = await post('/info', {
        deviceId,
        devicetype: '2',
        devicename: 'iPhone',
        language: '1',
        authtoken,
        token: jwt,
    });
    return parseResponse(raw);
}

async function nodeList(authtoken, jwt, deviceId) {
    const raw = await post('/node_list', {
        deviceId,
        devicetype: '2',
        devicename: 'iPhone',
        language: '1',
        authtoken,
        token: jwt,
    });
    return parseResponse(raw);
}

async function main() {
    API_BASE = await fetchApiBase();
    console.log(`[*] API: ${API_BASE}`);

    const deviceId = crypto.randomUUID();
    const loginRes = await travelerLogin(deviceId);
    if (!loginRes.data?.token) {
        console.log('[!] login failed');
        return;
    }

    const {
        token: authtoken,
        auth_data: jwt
    } = loginRes.data;
    console.log(`[*] authtoken: ${authtoken}`);

    const infoRes = await info(authtoken, jwt, deviceId);
    console.log('[*] info:', JSON.stringify(infoRes));

    const nodeRes = await nodeList(authtoken, jwt, deviceId);
    if (nodeRes.data && Array.isArray(nodeRes.data)) {
        const allNodes = nodeRes.data.flatMap(g => g.node || []);
        const outFile = path.join(path.dirname(process.argv[1]), 'nodes.txt');
        fs.writeFileSync(outFile, allNodes.join('\n'), 'utf8');
        console.log(`[*] ${allNodes.length} nodes -> ${outFile}`);
    }
}

main().catch(e => console.error('FATAL:', e));

module.exports = {
    decryptResponse,
    encryptRequest,
    travelerLogin,
    info,
    nodeList
};