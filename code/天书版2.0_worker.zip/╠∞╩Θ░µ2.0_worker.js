//1、天书版2.0，支持反代功能，极简优化，错误率低于千分之一，最终版本，没什么好折腾的了
//2、支持反代开关，私钥开关，订阅隐藏开关功能，去除UUID限制，clash私钥防止被薅请求数
//3、不用在意那些奇怪的变量名，根据后面注释的备注去改，大概也就前100行看一下备注就行，clash配置在底部，懂的可以根据自身需求修改
//4、纯手搓配置，节点位不能留空，不然会订阅失败，去除任何API外链，不支持任何外部变量修改和API，直接在线workers改好了部署就行，这样安全性史无前例
//5、虽然加入了通用base64订阅，但是本人并未测试，请自行测试研究，如果不能用就算了，概不负责^_^
//6、由于本人仅使用openclash和clash meta，其他平台软件均未测试，请自行测试研究，要是不能用就算了，不负责改进，继续概不负责^_^

import { connect } from 'cloudflare:sockets';

let 叧叨叭叱叴 = [""]; //这是你的ID，去除UUID规格限制，支持大小写字母和数字任意组合，安全性提高更不容易扫出

let 叵叺叻叼叽叾卟 = [""]; //这是你的私钥，提高隐秘性安全性，就算别人扫到你的域名也无法链接，再也不怕别人薅请求数了^_^
let 叿吀吁吂吅 = true //是否启用私钥功能，true启用，false不启用，因为私钥功能只支持clash，如果打算使用base64订阅则需关闭私钥功能

let 吆吇吋吒 = false //选择是否隐藏订阅页面，默认false不隐藏，true隐藏，当然隐藏后自己也无法订阅，因为配置固定，适合自己订阅后就隐藏，防止被爬订阅，并且可以到下方根据备注添加嘲讽语^_^

const 吔吖吘吙吚 = 'vl'
const 吔吖吘吙吚2 = 'ess'
const 吜吡吢吣吤 = '://'

const 吥吧吩吪吭 = 'cla'
const 吮吰吱吲 = 'sh'

const 呐吷吺 = '/?ed=2560' //回落路径，一般不用改 '/?ed=2560' 使用这个代码并开启域名--速度--优化--协议优化--0-RTT连接恢复，可以改善使用体验，猜的^_^

const 吽呁呃呄呅 = 'www.visa.com' //CF的节点，填域名或IP，好的优选一个就够了，由于CFcdn常规13个端口开放，可以生成4个notls和4个tls节点，只保留了8个非常规端口的

const 呇呉呋呋呌呍呎 = true //选择是否启用反代功能，true启用，false不启用，现在你可以自由的选择是否启用反代功能了
const 呏呐呒呓呔呕 = 'www.visa.com' //反代IP或域名，不需要填端口，反代IP只是兜底策略，不能固定落地地区，可以结合非CF节点一起用并选择该节点，固定落地地区

const 呗呙呚呛 = 'www.visa.com' //非CF的节点，填域名或IP，结合你的反代一起使用的话，这个节点可以完全的固定落地地区
const 呜呝呞呟呠 = '443' //非CF的节点端口
const 呡呢呣呤呥 = 'true' //非CF的节点TLS开关，true启用，false不启用，base64订阅此功能无效，默认使用tls

const 呦呧周呩呪 = 'www.visa.com' //备用节点，可以填自己的workers绑定的域名，CF自动小黄云代理，相当于有一个永久有效的备份节点，永不失联[这方法只针对托管域名到CF的玩家]
const 呫呬呭呮呯 = '443' //端口
const 呰呱呲呴呶呵 = 'true' //TLS开关，true启用，false不启用，base64订阅此功能无效，默认使用tls

const 呷呸呹呺呻 = 'www.visa.com' //IPV6备用节点，改了双栈优先IPV6，意思同上，都是自定义的，想填备份的也行，想填别人的或自己的vps也行，填自己优选的官方IPV6也行
const 呾呿咀咁咂 = '443' //端口
const 咃咄咅咇咈 = 'true' //TLS开关，true启用，false不启用，base64订阅此功能无效，默认使用tls

const 我的节点名字 = '' //自己的节点名字

export default {
    async fetch(圠圡圢圤圥圦, 圧圩圪圫圬圮) {
        叧叨叭叱叴 = 圧圩圪圫圬圮.UID || 叧叨叭叱叴;
        const 圯地圱圲圳圴圵圶 = 圠圡圢圤圥圦.headers.get('Upgrade');
        if (!圯地圱圲圳圴圵圶 || 圯地圱圲圳圴圵圶 !== 'websocket') {
            const url = new URL(圠圡圢圤圥圦.url);
            switch (url.pathname) {
                case `/${叧叨叭叱叴}`: {
                    const 圷圸圹圻圼埢鴪址 = 坁坂坃坄坅坆(叧叨叭叱叴, 圠圡圢圤圥圦.headers.get('Host'));
                    return new Response(`${圷圸圹圻圼埢鴪址}`, {
                        status: 200,
                        headers: {
                            "Content-Type": "text/plain;charset=utf-8",
                        }
                    });
                }
                case `/${叧叨叭叱叴}/base64`: {
                    if (吆吇吋吒) {
                    return new Response (`哎呀你找到了我，但是我就是不给你看，气不气，嘿嘿嘿`, { //可以在这里添加你的嘲讽语句，气死个人，哈哈哈
                    status: 200,
                    headers: {
                        "Content-Type": "text/plain;charset=utf-8",
                        }
                    });
                    } else {
                    const 坈坉坊坋 = 坌坍坒坓坔(叧叨叭叱叴, 圠圡圢圤圥圦.headers.get('Host'));
                    return new Response(`${坈坉坊坋}`, {
                        status: 200,
                        headers: {
                            "Content-Type": "text/plain;charset=utf-8",
                        }
                    });
                  }
                }
                case `/${叧叨叭叱叴}/${吥吧吩吪吭}${吮吰吱吲}`: {
                    if (吆吇吋吒) {
                    return new Response (`哎呀你找到了我，但是我就是不给你看，气不气，嘿嘿嘿`, { //可以在这里添加你的嘲讽语句，气死个人，哈哈哈
                    status: 200,
                    headers: {
                        "Content-Type": "text/plain;charset=utf-8",
                        }
                    });
                    } else {
                    const 坕坖坘坙坜坞 = 坢坣坥坧坨(叧叨叭叱叴, 圠圡圢圤圥圦.headers.get('Host'));
                    return new Response(`${坕坖坘坙坜坞}`, {
                        status: 200,
                        headers: {
                            "Content-Type": "text/plain;charset=utf-8",
                        }
                    });
                  }
                }
                default:
                    url.hostname = ''; //在这里添加伪装域名网站，建议自建的站点，或者国外小站;
                    url.protocol = 'https:';
                    圠圡圢圤圥圦 = new Request(url, 圠圡圢圤圥圦);
                    return await fetch(圠圡圢圤圥圦);
            }
        } else {
            const 坩坪坫坬坭坮 = 圠圡圢圤圥圦.headers.get('my-key')
            if (坩坪坫坬坭坮 == 叵叺叻叼叽叾卟) {
            return await 坯垧坱坲坳(圠圡圢圤圥圦);
            }
            if (!叿吀吁吂吅) {
            return await 坯垧坱坲坳(圠圡圢圤圥圦);
            }
        }
    }
};
async function 坯垧坱坲坳(圠圡圢圤圥圦) {
    const 奵奺奻奼奾 = new WebSocketPair();
    const [奿妀妁妅妉, 妋妌妍妎妏] = Object.values(奵奺奻奼奾);
    妋妌妍妎妏.accept();
    const 妑妔妕妗妘妚 = 圠圡圢圤圥圦.headers.get('sec-websocket-protocol') || '';
    const 妛妜妟妠妡妢妤 = 妧妩妫妭妮妯(妋妌妍妎妏, 妑妔妕妗妘妚);
    let 妷妸妺妼妽妿 = { value: null, };
    妛妜妟妠妡妢妤.pipeTo(new WritableStream({
        async write(姁姂姃姄姅) {
            if (妷妸妺妼妽妿.value) {
                const writer = 妷妸妺妼妽妿.value.writable.getWriter()
                await writer.write(姁姂姃姄姅);
                writer.releaseLock();
                return;
            }
            const {
                姆姇姈姉姊 = '',
                姌姗姎姏姒姕 = '',
                姙姛姝姞,
                姟姠姡姢姣 = new Uint8Array([0, 0]),
            } = await 姳姴姵姶姷(姁姂姃姄姅);
            const 姹姺姻姼姽姾 = new Uint8Array([姟姠姡姢姣[0], 姟姠姡姢姣[1]]);
            const 娀威娂娅娆娈娉 = 姁姂姃姄姅.slice(姙姛姝姞);
            峪峬峫峭峮峯峱(妷妸妺妼妽妿, 姆姇姈姉姊, 姌姗姎姏姒姕, 娀威娂娅娆娈娉, 妋妌妍妎妏, 姹姺姻姼姽姾);
        },
    }));
    return new Response(null, {
        status: 101,
        webSocket: 奿妀妁妅妉,
    });
}
function 妧妩妫妭妮妯(敳屮屰屲屳, 屴屵屶屷) {
  	const 屸屹屺屻屼 = new ReadableStream({
  	  	start(屽屾屿岃岄) {
  	  	  	敳屮屰屲屳.addEventListener('message', (event) => {
  	  	  	    const message = event.data;
  	  	  	    屽屾屿岃岄.enqueue(message);
  	  	  	});
  	  	  	敳屮屰屲屳.addEventListener('close', () => {
                屽屾屿岃岄.close();
  	  	  	});
  	  	  	const {earlyData} = 岅岆岇岈岉岊岋(屴屵屶屷);
  	  	  	if (earlyData) { 屽屾屿岃岄.enqueue(earlyData); };
  	  	}
  	});
  	return 屸屹屺屻屼;
}
function 岅岆岇岈岉岊岋(岌岍岎岏岐) {
    岌岍岎岏岐 = 岌岍岎岏岐.replace(/-/g, '+').replace(/_/g, '/');
    const 岒岓岔岕岖 = atob(岌岍岎岏岐);
    const 岘岙岚岜岝岞 = Uint8Array.from(岒岓岔岕岖, (c) => c.charCodeAt(0));
    return { earlyData: 岘岙岚岜岝岞.buffer };
}
async function 姳姴姵姶姷(岟岠岗岢岣岤) {
  	const 岥岦岧岨岪 = new Uint8Array(岟岠岗岢岣岤.slice(0, 1));
  	const 岬岮岯岰岲 = new Uint8Array(岟岠岗岢岣岤.slice(17, 18))[0];
  	const 岴岵岶岷岹岺 = 18 + 岬岮岯岰岲 + 1;
  	const 岼岽岾岿峀 = 岟岠岗岢岣岤.slice(岴岵岶岷岹岺, 岴岵岶岷岹岺 + 2);
  	const 姌姗姎姏姒姕 = new DataView(岼岽岾岿峀).getUint16(0);
  	const 峁峂峃峄峅 = 岴岵岶岷岹岺 + 2;
  	const 峆峇峈峉峊峋 = new Uint8Array(岟岠岗岢岣岤.slice(峁峂峃峄峅, 峁峂峃峄峅 + 1));
  	const 峌峍峎峏峐峑 = 峆峇峈峉峊峋[0];
  	let 崓峖峗峘峚 = 0;
  	let 峙峛峜峝峞峟 = '';
  	let 峠峢峣峤峥峦峧峨 = 峁峂峃峄峅 + 1;
  	switch (峌峍峎峏峐峑) {
  	  	case 1:
  	  	    崓峖峗峘峚 = 4;
  	  	    峙峛峜峝峞峟 = new Uint8Array(
  	  	        岟岠岗岢岣岤.slice(峠峢峣峤峥峦峧峨, 峠峢峣峤峥峦峧峨 + 崓峖峗峘峚)
  	  	    ).join('.');
  	  	    break;
  	  	case 2:
  	  	    崓峖峗峘峚 = new Uint8Array(
  	  	        岟岠岗岢岣岤.slice(峠峢峣峤峥峦峧峨, 峠峢峣峤峥峦峧峨 + 1)
  	  	    )[0];
  	  	    峠峢峣峤峥峦峧峨 += 1;
  	  	    峙峛峜峝峞峟 = new TextDecoder().decode(
  	  	        岟岠岗岢岣岤.slice(峠峢峣峤峥峦峧峨, 峠峢峣峤峥峦峧峨 + 崓峖峗峘峚)
  	  	    );
  	  	    break;
  	  	case 3:
  	  	    崓峖峗峘峚 = 16;
  	  	    const dataView = new DataView(
  	  	        岟岠岗岢岣岤.slice(峠峢峣峤峥峦峧峨, 峠峢峣峤峥峦峧峨 + 崓峖峗峘峚)
  	  	    );
  	  	    const ipv6 = [];
  	  	    for (let i = 0; i < 8; i++) {
  	  	        ipv6.push(dataView.getUint16(i * 2).toString(16));
  	  	    }
  	  	    峙峛峜峝峞峟 = ipv6.join(':');
  	  	    break;
  	} 	
  	return {
  	  	姆姇姈姉姊: 峙峛峜峝峞峟,
  	  	峌峍峎峏峐峑,
  	  	姌姗姎姏姒姕,
  	  	姙姛姝姞: 峠峢峣峤峥峦峧峨 + 崓峖峗峘峚,
  	  	姟姠姡姢姣: 岥岦岧岨岪,
  	};
}
async function 峪峬峫峭峮峯峱(妷妸妺妼妽妿, 姆姇姈姉姊, 姌姗姎姏姒姕, 娀威娂娅娆娈娉, 妋妌妍妎妏, 岘峵峷峸峹) {
  	async function 峺峼峾峿崀(崁崂崃崄, 崅崆崇崈崉) {
  	    const 崊崋崌崃崎崏 = connect({ hostname: 崁崂崃崄, port: 崅崆崇崈崉, });
  	    妷妸妺妼妽妿.value = 崊崋崌崃崎崏;
  	    const writer = 崊崋崌崃崎崏.writable.getWriter();
  	    await writer.write(娀威娂娅娆娈娉);
  	    writer.releaseLock();
  	    return 崊崋崌崃崎崏;
  	}
  	async function 崐崒崓崔崕() {
  	    const 崊崋崌崃崎崏 = await 峺峼峾峿崀(呏呐呒呓呔呕 || 姆姇姈姉姊, 姌姗姎姏姒姕)
  	    崜崝崞崟岽崡(崊崋崌崃崎崏, 妋妌妍妎妏, 岘峵峷峸峹, null);
  	}
  	    const 崊崋崌崃崎崏 = await 峺峼峾峿崀(姆姇姈姉姊, 姌姗姎姏姒姕);
  	    崜崝崞崟岽崡(崊崋崌崃崎崏, 妋妌妍妎妏, 岘峵峷峸峹, 崐崒崓崔崕);
}
async function 崜崝崞崟岽崡(怶怷怸怹怺怼, 妋妌妍妎妏, 悙怿恀恁恂恃, 恑恒恓恔恖恗) {
  	let VL标头 = 悙怿恀恁恂恃;
  	let 恝恞恠恡恦 = false;
  	await 怶怷怸怹怺怼.readable.pipeTo(new WritableStream({ 
  	  	  	async write(恫恬恮恰恱恲) {
  	  	  	    恝恞恠恡恦 = true;
  	  	  	    if (VL标头) {
  	  	  	        妋妌妍妎妏.send(await new Blob([VL标头, 恫恬恮恰恱恲]).arrayBuffer());
  	  	  	        VL标头 = null;
  	  	  	    } else {
  	  	  	        妋妌妍妎妏.send(恫恬恮恰恱恲);
  	  	  	    }
  	  	  	},
  	  	})
  	);
  	if (呇呉呋呋呌呍呎) {
  	    if (恝恞恠恡恦 === false && 恑恒恓恔恖恗) {
  	        恑恒恓恔恖恗();
  	    }
  	}
}
//坕坖坘坙坜坞
function 坁坂坃坄坅坆(叧叨叭叱叴, hostName) {
return `
本worker的私钥功能只支持${吥吧吩吪吭}${吮吰吱吲}，若使用base64订阅请关闭私钥功能，其他需求自行研究
Base64 通用的：https://${hostName}/${叧叨叭叱叴}/base64
猫咪的：https${吜吡吢吣吤}${hostName}/${叧叨叭叱叴}/${吥吧吩吪吭}${吮吰吱吲}
`;
}
function 坌坍坒坓坔(叧叨叭叱叴, hostName) {
  const 特殊长链接Links = btoa(`${吔吖吘吙吚}${吔吖吘吙吚2}${吜吡吢吣吤}${叧叨叭叱叴}@${吽呁呃呄呅}:2052?encryption=none&security=none&fp=randomized&type=ws&host=${hostName}&path=%2F%3Fed%3D2560\n${吔吖吘吙吚}${吔吖吘吙吚2}${吜吡吢吣吤}${叧叨叭叱叴}@${吽呁呃呄呅}:2082?encryption=none&security=none&fp=randomized&type=ws&host=${hostName}&path=%2F%3Fed%3D2560\n${吔吖吘吙吚}${吔吖吘吙吚2}${吜吡吢吣吤}${叧叨叭叱叴}@${吽呁呃呄呅}:2086?encryption=none&security=none&fp=randomized&type=ws&host=${hostName}&path=%2F%3Fed%3D2560\n${吔吖吘吙吚}${吔吖吘吙吚2}${吜吡吢吣吤}${叧叨叭叱叴}@${吽呁呃呄呅}:2095?encryption=none&security=none&fp=randomized&type=ws&host=${hostName}&path=%2F%3Fed%3D2560\n${吔吖吘吙吚}${吔吖吘吙吚2}${吜吡吢吣吤}${叧叨叭叱叴}@${吽呁呃呄呅}:2053?encryption=none&security=tls&sni=${hostName}&fp=randomized&type=ws&host=${hostName}&path=%2F%3Fed%3D2560\n${吔吖吘吙吚}${吔吖吘吙吚2}${吜吡吢吣吤}${叧叨叭叱叴}@${吽呁呃呄呅}:2083?encryption=none&security=tls&sni=${hostName}&fp=randomized&type=ws&host=${hostName}&path=%2F%3Fed%3D2560\n${吔吖吘吙吚}${吔吖吘吙吚2}${吜吡吢吣吤}${叧叨叭叱叴}@${吽呁呃呄呅}:2087?encryption=none&security=tls&sni=${hostName}&fp=randomized&type=ws&host=${hostName}&path=%2F%3Fed%3D2560\n${吔吖吘吙吚}${吔吖吘吙吚2}${吜吡吢吣吤}${叧叨叭叱叴}@${吽呁呃呄呅}:2096?encryption=none&security=tls&sni=${hostName}&fp=randomized&type=ws&host=${hostName}&path=%2F%3Fed%3D2560\n${吔吖吘吙吚}${吔吖吘吙吚2}${吜吡吢吣吤}${叧叨叭叱叴}@${呗呙呚呛}:${呜呝呞呟呠}?encryption=none&security=tls&sni=${hostName}&fp=randomized&type=ws&host=${hostName}&path=%2F%3Fed%3D2560\n${吔吖吘吙吚}${吔吖吘吙吚2}${吜吡吢吣吤}${叧叨叭叱叴}@${呦呧周呩呪}:${呫呬呭呮呯}?encryption=none&security=tls&sni=${hostName}&fp=randomized&type=ws&host=${hostName}&path=%2F%3Fed%3D2560\n${吔吖吘吙吚}${吔吖吘吙吚2}${吜吡吢吣吤}${叧叨叭叱叴}@${呷呸呹呺呻}:${呾呿咀咁咂}?encryption=none&security=tls&sni=${hostName}&fp=randomized&type=ws&host=${hostName}&path=%2F%3Fed%3D2560`);
  return `${特殊长链接Links}`
}
function 坢坣坥坧坨(叧叨叭叱叴, hostName) {
return `
dns:
  nameserver:
    - 119.29.29.29
    - 223.5.5.5
  fallback:
    - 8.8.8.8
    - tls://dns.google
    - 2001:4860:4860::8888
proxies:
- name: ${我的节点名字}-notls-2052
  type: ${吔吖吘吙吚}${吔吖吘吙吚2}
  server: ${吽呁呃呄呅}
  port: 2052
  uuid: ${叧叨叭叱叴}
  udp: false
  tls: false
  network: ws
  ws-opts:
    path: "${呐吷吺}"
    headers:
      Host: ${hostName}
      my-key: ${叵叺叻叼叽叾卟}
- name: ${我的节点名字}-notls-2082
  type: ${吔吖吘吙吚}${吔吖吘吙吚2}
  server: ${吽呁呃呄呅}
  port: 2082
  uuid: ${叧叨叭叱叴}
  udp: false
  tls: false
  network: ws
  ws-opts:
    path: "${呐吷吺}"
    headers:
      Host: ${hostName}
      my-key: ${叵叺叻叼叽叾卟}
- name: ${我的节点名字}-notls-2086
  type: ${吔吖吘吙吚}${吔吖吘吙吚2}
  server: ${吽呁呃呄呅}
  port: 2086
  uuid: ${叧叨叭叱叴}
  udp: false
  tls: false
  network: ws
  ws-opts:
    path: "${呐吷吺}"
    headers:
      Host: ${hostName}
      my-key: ${叵叺叻叼叽叾卟}
- name: ${我的节点名字}-notls-2095
  type: ${吔吖吘吙吚}${吔吖吘吙吚2}
  server: ${吽呁呃呄呅}
  port: 2095
  uuid: ${叧叨叭叱叴}
  udp: false
  tls: false
  network: ws
  ws-opts:
    path: "${呐吷吺}"
    headers:
      Host: ${hostName}
      my-key: ${叵叺叻叼叽叾卟}
- name: ${我的节点名字}-tls-2053
  type: ${吔吖吘吙吚}${吔吖吘吙吚2}
  server: ${吽呁呃呄呅}
  port: 2053
  uuid: ${叧叨叭叱叴}
  udp: false
  tls: true
  network: ws
  ws-opts:
    path: "${呐吷吺}"
    headers:
      Host: ${hostName}
      my-key: ${叵叺叻叼叽叾卟}
- name: ${我的节点名字}-tls-2083
  type: ${吔吖吘吙吚}${吔吖吘吙吚2}
  server: ${吽呁呃呄呅}
  port: 2083
  uuid: ${叧叨叭叱叴}
  udp: false
  tls: true
  network: ws
  ws-opts:
    path: "${呐吷吺}"
    headers:
      Host: ${hostName}
      my-key: ${叵叺叻叼叽叾卟}
- name: ${我的节点名字}-tls-2087
  type: ${吔吖吘吙吚}${吔吖吘吙吚2}
  server: ${吽呁呃呄呅}
  port: 2087
  uuid: ${叧叨叭叱叴}
  udp: false
  tls: true
  network: ws
  ws-opts:
    path: "${呐吷吺}"
    headers:
      Host: ${hostName}
      my-key: ${叵叺叻叼叽叾卟}
- name: ${我的节点名字}-tls-2096
  type: ${吔吖吘吙吚}${吔吖吘吙吚2}
  server: ${吽呁呃呄呅}
  port: 2096
  uuid: ${叧叨叭叱叴}
  udp: false
  tls: true
  network: ws
  ws-opts:
    path: "${呐吷吺}"
    headers:
      Host: ${hostName}
      my-key: ${叵叺叻叼叽叾卟}
- name: ${我的节点名字}-非CF节点
  type: ${吔吖吘吙吚}${吔吖吘吙吚2}
  server: ${呗呙呚呛}
  port: ${呜呝呞呟呠}
  uuid: ${叧叨叭叱叴}
  udp: false
  tls: ${呡呢呣呤呥}
  network: ws
  ws-opts:
    path: "${呐吷吺}"
    headers:
      Host: ${hostName}
      my-key: ${叵叺叻叼叽叾卟}
- name: ${我的节点名字}-备用IPV4节点
  type: ${吔吖吘吙吚}${吔吖吘吙吚2}
  server: ${呦呧周呩呪}
  port: ${呫呬呭呮呯}
  uuid: ${叧叨叭叱叴}
  udp: false
  tls: ${呰呱呲呴呶呵}
  network: ws
  ws-opts:
    path: "${呐吷吺}"
    headers:
      Host: ${hostName}
      my-key: ${叵叺叻叼叽叾卟}
- name: ${我的节点名字}-备用IPV6节点
  type: ${吔吖吘吙吚}${吔吖吘吙吚2}
  server: ${呷呸呹呺呻}
  port: ${呾呿咀咁咂}
  ip-version: ipv6-prefer  # ip-version设置，可以自定义强制走ipv4或ipv6，ipv6-prefer则是双栈优先走ipv6
  uuid: ${叧叨叭叱叴}
  udp: false
  tls: ${咃咄咅咇咈}
  network: ws
  ws-opts:
    path: "${呐吷吺}"
    headers:
      Host: ${hostName}
      my-key: ${叵叺叻叼叽叾卟}
proxy-groups:
- name: 🚀 节点选择
  type: select
  proxies:
    - notls负载均衡
    - tls负载均衡
    - 自动选择
    - ${我的节点名字}-notls-2052
    - ${我的节点名字}-notls-2082
    - ${我的节点名字}-notls-2086
    - ${我的节点名字}-notls-2095
    - ${我的节点名字}-tls-2053
    - ${我的节点名字}-tls-2083
    - ${我的节点名字}-tls-2087
    - ${我的节点名字}-tls-2096
    - ${我的节点名字}-非CF节点
    - ${我的节点名字}-备用IPV4节点
    - ${我的节点名字}-备用IPV6节点
- name: 自动选择
  type: url-test
  url: http://www.gstatic.com/generate_204
  interval: 300
  tolerance: 50
  proxies:
    - ${我的节点名字}-notls-2052
    - ${我的节点名字}-notls-2082
    - ${我的节点名字}-notls-2086
    - ${我的节点名字}-notls-2095
    - ${我的节点名字}-tls-2053
    - ${我的节点名字}-tls-2083
    - ${我的节点名字}-tls-2087
    - ${我的节点名字}-tls-2096
    - ${我的节点名字}-非CF节点
    - ${我的节点名字}-备用IPV4节点
    - ${我的节点名字}-备用IPV6节点
- name: notls负载均衡
  type: load-balance
  url: http://www.gstatic.com/generate_204
  interval: 300
  proxies:
    - ${我的节点名字}-notls-2052
    - ${我的节点名字}-notls-2082
    - ${我的节点名字}-notls-2086
    - ${我的节点名字}-notls-2095
- name: tls负载均衡
  type: load-balance
  url: http://www.gstatic.com/generate_204
  interval: 300
  proxies:
    - ${我的节点名字}-tls-2053
    - ${我的节点名字}-tls-2083
    - ${我的节点名字}-tls-2087
    - ${我的节点名字}-tls-2096
- name: 非CF节点
  type: select
  proxies:
    - ${我的节点名字}-非CF节点
- name: 漏网之鱼
  type: select
  proxies:
    - DIRECT
    - 🚀 节点选择
    - 非CF节点
rules:
# 策略规则，部分规则需打开clash mate的使用geoip dat版数据库，比如TG规则就需要，或者自定义geoip的规则订阅
# 这是geoip的规则订阅链接，https://cdn.jsdelivr.net/gh/Loyalsoldier/geoip@release/Country.mmdb
# GPT规则
- DOMAIN-KEYWORD,openai,🚀 节点选择
- DOMAIN-SUFFIX,AI.com,🚀 节点选择
- DOMAIN-SUFFIX,cdn.auth0.com,🚀 节点选择
- DOMAIN-SUFFIX,openaiapi-site.azureedge.net,🚀 节点选择
- DOMAIN-SUFFIX,opendns.com,🚀 节点选择
- DOMAIN-SUFFIX,bing.com,🚀 节点选择
- DOMAIN-SUFFIX,civitai.com,🚀 节点选择
- DOMAIN,bard.google.com,🚀 节点选择
- DOMAIN,ai.google.dev,🚀 节点选择
- DOMAIN,gemini.google.com,🚀 节点选择
- DOMAIN-SUFFIX,googleapis.com,🚀 节点选择
- DOMAIN-SUFFIX,sentry.io,🚀 节点选择
- DOMAIN-SUFFIX,intercom.io,🚀 节点选择
- DOMAIN-SUFFIX,featuregates.org,🚀 节点选择
- DOMAIN-SUFFIX,statsigapi.net,🚀 节点选择
- DOMAIN-SUFFIX,claude.ai,🚀 节点选择
- DOMAIN-SUFFIX,Anthropic.com,🚀 节点选择
- DOMAIN-SUFFIX,opera-api.com,🚀 节点选择
- DOMAIN-SUFFIX,aistudio.google.com,🚀 节点选择
- DOMAIN-SUFFIX,auth0.com,🚀 节点选择
- DOMAIN-SUFFIX,challenges.cloudflare.com,🚀 节点选择
- DOMAIN-SUFFIX,chatgpt.com,🚀 节点选择
- DOMAIN-SUFFIX,client-api.arkoselabs.com,🚀 节点选择
- DOMAIN-SUFFIX,events.statsigapi.net,🚀 节点选择
- DOMAIN-SUFFIX,identrust.com,🚀 节点选择
- DOMAIN-SUFFIX,intercomcdn.com,🚀 节点选择
- DOMAIN-SUFFIX,oaistatic.com,🚀 节点选择
- DOMAIN-SUFFIX,oaiusercontent.com,🚀 节点选择
- DOMAIN-SUFFIX,openai.com,🚀 节点选择
- DOMAIN-SUFFIX,stripe.com,🚀 节点选择
# GPT规则
- GEOSITE,category-ads,REJECT #简单广告过滤规则，要增加规则数可使用category-ads-all
- GEOSITE,cn,DIRECT #国内域名直连规则
- GEOIP,CN,DIRECT,no-resolve #国内IP直连规则
- GEOSITE,cloudflare,DIRECT #CF域名直连规则
- GEOIP,CLOUDFLARE,DIRECT,no-resolve #CFIP直连规则
- GEOSITE,gfw,🚀 节点选择 #GFW域名规则
- GEOSITE,google,🚀 节点选择 #GOOGLE域名规则
- GEOIP,GOOGLE,🚀 节点选择,no-resolve #GOOGLE IP规则
- GEOSITE,netflix,🚀 节点选择 #奈飞域名规则
- GEOIP,NETFLIX,🚀 节点选择,no-resolve #奈飞IP规则
- GEOSITE,telegram,🚀 节点选择 #TG域名规则
- GEOIP,TELEGRAM,🚀 节点选择,no-resolve #TG IP规则
- MATCH,漏网之鱼
`
}