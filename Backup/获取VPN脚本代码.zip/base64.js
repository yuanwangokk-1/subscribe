const fs = require('fs');
const path = require('path');

// 输入文件路径（请确保 nodes.txt 位于当前工作目录）
const inputFile = path.join(__dirname, 'nodes.txt');
// 输出文件路径（可根据需要修改或注释掉文件输出部分）
const outputFile = path.join(__dirname, 'node_base64.txt');

// 读取文件并进行 Base64 编码
fs.readFile(inputFile, (err, data) => {
  if (err) {
    console.error(`读取文件失败: ${err.message}`);
    return;
  }

  // 将文件内容转为 Base64 字符串
  const base64Content = data.toString('base64');

  // 输出到控制台（可选）
  console.log('Base64 编码结果：\n', base64Content);

  // 将编码结果写入新文件
  fs.writeFile(outputFile, base64Content, (writeErr) => {
    if (writeErr) {
      console.error(`写入文件失败: ${writeErr.message}`);
      return;
    }
    console.log(`✅ Base64 编码结果已保存至: ${outputFile}`);
  });
});
